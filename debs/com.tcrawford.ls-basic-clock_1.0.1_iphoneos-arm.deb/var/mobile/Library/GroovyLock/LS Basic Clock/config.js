// 24 hour time = true; 12 hour time = false
var twentyfourhourtime = false;

// Show background color = true; Don't show = false
var showBackground = true;

// The color of the clock, uncomment next line to revert to default color if forgotten
// var timeColor = "#606060";
var timeColor = "#606060";

// Background color behind the clock, uncomment to revert to default color if forgotten
// var bgColor = "rgba(240, 240, 240, 0.5)";
var bgColor = "rgba(240, 240, 240, 0.5)";

// The position in pixels that the clock will appear from the top of the screen
// (negative values are allowed)
var clockPosFromTop = "0";
