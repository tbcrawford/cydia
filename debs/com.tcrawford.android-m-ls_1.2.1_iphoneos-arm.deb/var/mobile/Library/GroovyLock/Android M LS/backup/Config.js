var twentyFourHourTime = false; // 24 hour clock - true; 12 hour clock - false
var timeColor = "#FFFFFF"; // Color of the time
var dateColor = "#FFFFFF"; // Color of the date
var clockFontSize = "102px"; // The clock's font size
var dateFontSize = "16px"; // The date's font size
var clockPositionFromTop = 46; // Position from the top of the screen
var clockFont = "Roboto-Light"; // Options: Roboto-Regular, Roboto-Medium, Roboto-Thin, or Roboto-Light
var dateFont = "Roboto-Regular"; // Options: Roboto-Regular, Roboto-Medium, Roboto-Thin, or Roboto-Light