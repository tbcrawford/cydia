var twentyFourHourTime = false;
var timeColor = "#303030";
var dateColor = "#303030";
var clockPosFromTop = 100;
var clockFont = 'Roboto-Regular'; // Options: 'Roboto-Regular', 'Roboto-Medium', 'Roboto-Thin', or 'Roboto-Light'
var dateFont = 'Roboto-Regular';  // Options: 'Roboto-Regular', 'Roboto-Medium', 'Roboto-Thin', or 'Roboto-Light'