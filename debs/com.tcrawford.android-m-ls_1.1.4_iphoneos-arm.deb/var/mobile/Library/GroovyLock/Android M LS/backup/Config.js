var twentyFourHourTime = false;
var timeColor = "#FFFFFF";
var dateColor = "#FFFFFF";
var clockPosFromTop = 100;
var clockFont = "Roboto-Thin"; // Options: "Roboto-Regular", "Roboto-Medium", "Roboto-Thin", or "Roboto-Light"
var dateFont = "Roboto-Light";  // Options: "Roboto-Regular", "Roboto-Medium", "Roboto-Thin", or "Roboto-Light"