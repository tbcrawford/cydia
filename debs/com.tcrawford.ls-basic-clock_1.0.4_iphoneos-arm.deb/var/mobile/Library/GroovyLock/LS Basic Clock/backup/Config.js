var twentyfourhourtime = false;
var showBackground = true;
var timeColor = "#606060";
var bgColor = "rgba(240, 240, 240, 0.5)";
var clockPosFromTop = 0;
