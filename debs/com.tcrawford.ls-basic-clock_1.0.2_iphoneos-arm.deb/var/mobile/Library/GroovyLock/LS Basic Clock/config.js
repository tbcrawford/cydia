// 24 hour time = true; 12 hour time = false
var twentyfourhourtime = false;

// Show background color = true; Don't show = false
var showBackground = true;

// The color of the clock
var timeColor = "#606060";

// Background color behind the clock
var bgColor = "rgba(240, 240, 240, 0.5)";

// The position in pixels that the clock will appear from the top of the screen
var clockPosFromTop = "0";
