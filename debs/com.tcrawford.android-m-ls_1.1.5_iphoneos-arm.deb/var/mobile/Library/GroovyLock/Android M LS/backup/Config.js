var twentyFourHourTime = false;
var timeColor = "#FFFFFF";
var dateColor = "#FFFFFF";
var clockPosFromTop = 100;
var clockFont = "Roboto-Light"; // Options: "Roboto-Regular", "Roboto-Medium", "Roboto-Thin", or "Roboto-Light"
var dateFont = "Roboto-Regular";  // Options: "Roboto-Regular", "Roboto-Medium", "Roboto-Thin", or "Roboto-Light"